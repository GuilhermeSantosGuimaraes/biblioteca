const conexao = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres",
    database: "biblioteca"
}

module.exports = {
    conexao
};
